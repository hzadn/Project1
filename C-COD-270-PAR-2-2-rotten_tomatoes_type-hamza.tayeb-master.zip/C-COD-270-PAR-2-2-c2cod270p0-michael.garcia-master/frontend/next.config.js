module.exports = {
    images: {
      domains: ["links.papareact.com", "image.tmdb.org", "zupimages.net", "lh3.googleusercontent.com"],
    },
  };